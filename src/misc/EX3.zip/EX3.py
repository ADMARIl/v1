from swampy.TurtleWorld import *
import math
world = TurtleWorld()
bob = Turtle()
bob.delay = 0.000
print bob
'''
fd(bob, 100)
lt(bob)

fd(bob, 100)
lt(bob)

fd(bob, 100)
lt(bob)

fd(bob, 100)
lt(bob)
java=javascript
'''

def square(t,length):
	for i in range(4):
		fd(bob, 100)
		lt(bob)
	
#square(bob, 100)

def makePoly(t, n, r):
	polygon(t, n, r)

def polygon(t,n,length):
	angle = 360.0 / n
	for i in range(n):
		triangle(t, length, angle/2)
		lt(t, angle)

def triangle(t, r, angle):
	ang = r*math.sin(angle*math.pi/180)
	rt(t, angle)
	fd(t, r)
	lt(t, 90+angle)
	fd(t, 2*ang)
	lt(t, 90+angle)
	fd(t, r)
	lt(t, 180-angle)
	#print 'java=javascript'

#change middle variable in makePoly to change num of sides
sides = input('Number of sides: ')
makePoly(bob, sides, 100)

def circle(t,r):
	circumference = 2 * math.pi * r
	n = int(circumference / 3) + 1
	length = circumference / n
	polygon(t,n,length)

wait_for_user()